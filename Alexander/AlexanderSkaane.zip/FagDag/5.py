adjektiver = ["snille", "varme", "blå"]
substantiver = ["elgen", "ballen", "personen"]
verb = ["går","løper","snakker"]

setning1 = print("Den " + adjektiver[2] + " " + substantiver[1] +" " + verb[1] + ".")